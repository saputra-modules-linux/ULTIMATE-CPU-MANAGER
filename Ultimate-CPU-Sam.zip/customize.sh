#!/system/bin/sh

# Tampilan Header saat Instalasi
ui_print "****************************************"
ui_print "        ULTIMATE CPU MANAGER          "
ui_print "****************************************"
ui_print " Author  : SAM KALI NETHUNTER         "
ui_print " Version : SCRIPT V1.0                "
ui_print " Date    : Monday, May 4, 2026        "
ui_print "****************************************"

# Keterangan Proses
ui_print "- Installing Snapdragon Tweaks..."
ui_print "- Setting up WebUI Server..."
ui_print "- Initializing Action Button..."

# Mengatur Permission (Wajib ada di customize.sh juga)
set_perm_recursive $MODPATH/webroot/cgi-bin 0 0 0755 0755
set_perm $MODPATH/action.sh 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755

ui_print "- Installation Completed Successfully!"
ui_print "- Please REBOOT your device."
ui_print "****************************************"
