#!/system/bin/sh
# ==========================================
# ULTIMATE CPU MANAGER - BACKGROUND SERVICE
# AUTHOR  : SAM KALI NETHUNTER
# DATE    : Monday, May 4, 2026
# ==========================================

MODDIR=${0%/*}

# 1. Tunggu sampai proses booting sistem stabil
sleep 30

# 2. Pastikan semua script memiliki izin eksekusi penuh
chmod -R 755 $MODDIR/webroot/cgi-bin
chmod 755 $MODDIR/action.sh
chmod 755 $MODDIR/service.sh

# 3. Jalankan Web Server (httpd busybox)
# Port: 8080 | Root folder: webroot
# Menjalankan server agar WebUI bisa diakses lewat Action Button
busybox httpd -p 8080 -h $MODDIR/webroot

# 4. Terapkan Profil Default (Seimbang) saat HP baru menyala
# Ini memastikan HP tidak langsung panas saat baru dinyalakan
export QUERY_STRING="balanced"
sh $MODDIR/webroot/cgi-bin/apply_cpu.sh

# 5. Log Identitas ke System Kernel (untuk pengecekan di logcat)
echo "ULTIMATE CPU MANAGER by SAM KALI NETHUNTER loaded!" > /dev/kmsg
echo "Release Date: Monday, May 4, 2026" > /dev/kmsg
