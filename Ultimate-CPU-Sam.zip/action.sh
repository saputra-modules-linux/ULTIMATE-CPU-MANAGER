#!/system/bin/sh
# ULTIMATE CPU MANAGER - Action Toggle
# Author: SAM KALI NETHUNTER
# Date: Monday, May 4, 2026

# Perintah untuk membuka browser secara otomatis ke alamat WebUI
am start -a android.intent.action.VIEW -d "http://localhost:8080"
