#!/system/bin/sh
# ==========================================
# ULTIMATE CPU MANAGER - SNAPDRAGON LOGIC
# AUTHOR  : SAM KALI NETHUNTER
# VERSION : SCRIPT V1.0
# RELEASE : MONDAY, MAY 4, 2026
# ==========================================

# Menangkap input dari WebUI (battery, balanced, overclock, brutaloverclock)
MODE=$QUERY_STRING

# Path Core Snapdragon (Little, Big, Prime)
LITTLE="/sys/devices/system/cpu/cpu0/cpufreq"
BIG="/sys/devices/system/cpu/cpu4/cpufreq"
GPU="/sys/class/kgsl/kgsl-3d0"

case $MODE in
    "battery")
        # --- Mode Hemat Baterai ---
        for i in /sys/devices/system/cpu/cpu*/cpufreq; do
            echo "powersave" > $i/scaling_governor
        done
        echo "1" > /sys/module/workqueue/parameters/power_efficient
        echo "1" > $GPU/default_pwrlevel
        ;;

    "balanced")
        # --- Mode Seimbang (Standard) ---
        for i in /sys/devices/system/cpu/cpu*/cpufreq; do
            echo "schedutil" > $i/scaling_governor
        done
        # Reset limit frekuensi ke default
        cat $LITTLE/cpuinfo_max_freq > $LITTLE/scaling_max_freq
        cat $BIG/cpuinfo_max_freq > $BIG/scaling_max_freq
        echo "5" > $GPU/default_pwrlevel
        ;;

    "overclock")
        # --- Mode Performa Gaming ---
        for i in /sys/devices/system/cpu/cpu*/cpufreq; do
            echo "performance" > $i/scaling_governor
        done
        # Boost GPU & L3 Cache
        echo "0" > $GPU/default_pwrlevel
        echo "performance" > $GPU/devfreq/governor
        ;;

    "brutaloverclock")
        # --- Mode BRUTAL (Author: SAM KALI NETHUNTER) ---
        # Paksa semua core ke Frekuensi Maksimal
        for i in /sys/devices/system/cpu/cpu*/cpufreq; do
            echo "performance" > $i/scaling_governor
            cat $i/cpuinfo_max_freq > $i/scaling_min_freq
        done
        
        # Kill Thermal Engine (Hapus batasan panas)
        stop thermal-engine
        stop vendor.thermal-engine
        echo 0 > /sys/module/msm_thermal/core_control/enabled
        
        # GPU Adreno Brutal Force
        echo "performance" > $GPU/devfreq/governor
        echo "1" > $GPU/force_no_nap
        echo "1" > $GPU/force_bus_on
        
        # Input Boost (Respon layar instan)
        if [ -d /sys/module/cpu_boost ]; then
            echo "0:1900000 4:2400000" > /sys/module/cpu_boost/parameters/input_boost_freq
        fi
        ;;
esac
